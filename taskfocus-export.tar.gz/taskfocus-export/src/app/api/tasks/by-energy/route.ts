import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { NextResponse } from "next/server";

// GET /api/tasks/by-energy - получение задач по уровню энергии
export async function GET(request: Request) {
  const user = await getCurrentUser();

  if (!user) {
    return NextResponse.json(
      {
        success: false,
        data: null,
        error: { code: "UNAUTHORIZED", message: "Не авторизован" },
      },
      { status: 401 }
    );
  }

  const { searchParams } = new URL(request.url);
  const currentEnergy = parseInt(searchParams.get("currentEnergy") || "3");

  // Получаем все активные корневые задачи
  const tasks = await db.task.findMany({
    where: {
      userId: user.id,
      status: "active",
      parentTaskId: null,
    },
    include: {
      subtasks: {
        orderBy: { createdAt: "asc" },
      },
    },
    orderBy: { energyLevel: "asc" },
  });

  // Разделяем по категориям энергии
  const matching = tasks.filter((t) => t.energyLevel <= currentEnergy);
  const challenging = tasks.filter(
    (t) => t.energyLevel === currentEnergy + 1 && currentEnergy < 5
  );
  const tooHard = tasks.filter((t) => t.energyLevel > currentEnergy + 1);

  return NextResponse.json({
    success: true,
    data: {
      matching,
      challenging,
      tooHard,
      currentEnergy,
    },
    error: null,
  });
}
