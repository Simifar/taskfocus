import { db } from "@/lib/db";
import { hashPassword, createToken } from "@/lib/auth";
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";

const registerSchema = z.object({
  email: z.string().email("Неверный формат email"),
  username: z.string().min(3, "Имя пользователя должно быть не менее 3 символов"),
  password: z.string().min(6, "Пароль должен быть не менее 6 символов"),
  name: z.string().optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const validatedData = registerSchema.parse(body);

    // Проверяем, существует ли пользователь
    const existingUser = await db.user.findFirst({
      where: {
        OR: [
          { email: validatedData.email },
          { username: validatedData.username },
        ],
      },
    });

    if (existingUser) {
      return NextResponse.json(
        {
          success: false,
          data: null,
          error: {
            code: "USER_EXISTS",
            message: "Пользователь с таким email или username уже существует",
          },
        },
        { status: 400 }
      );
    }

    // Хешируем пароль
    const passwordHash = await hashPassword(validatedData.password);

    // Создаем пользователя
    const user = await db.user.create({
      data: {
        email: validatedData.email,
        username: validatedData.username,
        passwordHash,
        name: validatedData.name,
      },
    });

    // Создаем токен
    const token = await createToken({
      userId: user.id,
      email: user.email,
      username: user.username,
    });

    // Устанавливаем cookie
    const cookieStore = await cookies();
    cookieStore.set("auth-token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 дней
      path: "/",
    });

    return NextResponse.json({
      success: true,
      data: {
        id: user.id,
        email: user.email,
        username: user.username,
        name: user.name,
        token,
      },
      error: null,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          success: false,
          data: null,
          error: {
            code: "VALIDATION_ERROR",
            message: error.errors[0].message,
          },
        },
        { status: 400 }
      );
    }

    console.error("Register error:", error);
    return NextResponse.json(
      {
        success: false,
        data: null,
        error: {
          code: "INTERNAL_ERROR",
          message: "Внутренняя ошибка сервера",
        },
      },
      { status: 500 }
    );
  }
}
