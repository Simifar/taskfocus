# TaskFocus — Интеллектуальный менеджер задач для пользователей с СДВГ

## 📋 Содержание

1. [Требования](#требования)
2. [Установка](#установка)
3. [Запуск](#запуск)
4. [Структура проекта](#структура-проекта)
5. [Технологии](#технологии)
6. [API документация](#api-документация)
7. [Деплой на сервер](#деплой-на-сервер)
8. [Продолжение разработки](#продолжение-разработки)

---

## Требования

### Вариант 1: Bun (рекомендуется)
- **Bun** >= 1.0.0
- **Node.js** >= 20 (для совместимости)

### Вариант 2: Node.js
- **Node.js** >= 20.0.0
- **npm** или **yarn** или **pnpm**

### Установка Bun (Windows/macOS/Linux)

**Windows (PowerShell):**
```powershell
powershell -c "irm bun.sh/install.ps1 | iex"
```

**macOS/Linux:**
```bash
curl -fsSL https://bun.sh/install | bash
```

**Проверка установки:**
```bash
bun --version
```

---

## Установка

### Шаг 1: Создайте папку проекта

```bash
mkdir taskfocus
cd taskfocus
```

### Шаг 2: Скопируйте файлы

Скопируйте все файлы из папки `taskfocus-export` в вашу папку проекта:

```
taskfocus/
├── src/
│   ├── app/
│   ├── components/
│   ├── lib/
│   ├── store/
│   └── types/
├── prisma/
├── public/
├── package.json
├── tsconfig.json
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.mjs
├── eslint.config.mjs
└── components.json
```

### Шаг 3: Создайте файл .env

Создайте файл `.env` в корне проекта:

```env
# База данных SQLite (по умолчанию)
DATABASE_URL="file:./db/database.db"

# Секретный ключ для JWT (обязательно замените на свой!)
JWT_SECRET="ваш-секретный-ключ-минимум-32-символа-для-безопасности"

# Режим работы
NODE_ENV="development"
```

### Шаг 4: Создайте папку для базы данных

```bash
mkdir db
```

### Шаг 5: Установите зависимости

```bash
bun install
```

### Шаг 6: Инициализируйте базу данных

```bash
bun run db:push
```

---

## Запуск

### Режим разработки

```bash
bun run dev
```

Приложение будет доступно по адресу: **http://localhost:3000**

### Продакшн режим

```bash
# Сборка
bun run build

# Запуск
bun run start
```

### Другие команды

```bash
# Проверка кода
bun run lint

# Генерация Prisma клиента
bun run db:generate

# Сброс базы данных
bun run db:reset
```

---

## Структура проекта

```
src/
├── app/                          # Next.js App Router
│   ├── api/                      # API маршруты
│   │   ├── auth/
│   │   │   ├── register/         # Регистрация
│   │   │   ├── login/            # Вход
│   │   │   ├── logout/           # Выход
│   │   │   └── me/               # Текущий пользователь
│   │   ├── tasks/
│   │   │   ├── [id]/             # CRUD задачи
│   │   │   │   └── complete/     # Завершение задачи
│   │   │   ├── by-energy/        # Фильтр по энергии
│   │   │   └── route.ts          # Список/создание
│   │   ├── subtasks/             # Подзадачи
│   │   └── stats/                # Статистика
│   ├── globals.css               # Глобальные стили
│   ├── layout.tsx                # Корневой layout
│   └── page.tsx                  # Главная страница
│
├── components/
│   ├── ui/                       # shadcn/ui компоненты
│   ├── auth/                     # Компоненты авторизации
│   ├── tasks/                    # Компоненты задач
│   └── dashboard.tsx             # Главный дашборд
│
├── lib/
│   ├── auth/                     # Аутентификация (JWT)
│   ├── db.ts                     # Prisma клиент
│   └── utils.ts                  # Утилиты
│
├── store/
│   └── index.ts                  # Zustand store
│
└── types/
    └── index.ts                  # TypeScript типы

prisma/
└── schema.prisma                 # Схема базы данных
```

---

## Технологии

| Категория | Технология | Версия |
|-----------|------------|--------|
| Framework | Next.js | 16.x |
| Язык | TypeScript | 5.x |
| Стили | Tailwind CSS | 4.x |
| UI компоненты | shadcn/ui | - |
| База данных | SQLite (Prisma ORM) | - |
| Состояние | Zustand | 5.x |
| Аутентификация | JWT (jose) | 6.x |
| Иконки | Lucide React | - |

---

## API документация

### Аутентификация

#### POST /api/auth/register
Регистрация нового пользователя.

```json
// Request
{
  "email": "user@example.com",
  "username": "username",
  "password": "password123",
  "name": "Иван Иванов"  // опционально
}

// Response
{
  "success": true,
  "data": {
    "id": "clx...",
    "email": "user@example.com",
    "username": "username",
    "token": "jwt-token"
  }
}
```

#### POST /api/auth/login
Вход в систему.

```json
// Request
{
  "email": "user@example.com",
  "password": "password123"
}
```

#### POST /api/auth/logout
Выход из системы.

#### GET /api/auth/me
Получение текущего пользователя.

---

### Задачи

#### GET /api/tasks
Получение списка задач.

**Query параметры:**
- `status` — фильтр по статусу (active, completed, archived)
- `energy` — фильтр по уровню энергии (1-5)
- `search` — поиск по названию

#### POST /api/tasks
Создание задачи (максимум 3 активных).

```json
{
  "title": "Новая задача",
  "description": "Описание",
  "priority": "medium",      // low, medium, high
  "energyLevel": 3,          // 1-5
  "dueDateStart": "2025-04-01",
  "dueDateEnd": "2025-04-05"
}
```

#### PUT /api/tasks/[id]
Обновление задачи.

#### DELETE /api/tasks/[id]
Удаление задачи.

#### POST /api/tasks/[id]/complete
Отметить задачу выполненной.

---

### Подзадачи

#### POST /api/subtasks
Создание подзадачи.

```json
{
  "parentId": "task-id",
  "title": "Подзадача",
  "energyLevel": 2
}
```

---

### Статистика

#### GET /api/stats
Получение статистики пользователя.

---

## Деплой на сервер

### Вариант 1: VPS (Ubuntu/Debian)

#### 1. Подключитесь к серверу
```bash
ssh user@your-server-ip
```

#### 2. Установите Bun
```bash
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc
```

#### 3. Создайте папку проекта
```bash
sudo mkdir -p /var/www/taskfocus
sudo chown $USER:$USER /var/www/taskfocus
cd /var/www/taskfocus
```

#### 4. Загрузите файлы
Через SCP или Git:
```bash
# Вариант A: SCP (с локальной машины)
scp -r taskfocus-export/* user@your-server:/var/www/taskfocus/

# Вариант B: Git
git clone https://github.com/your-username/taskfocus.git .
```

#### 5. Настройте окружение
```bash
# Создайте .env файл
cat > .env << EOF
DATABASE_URL="file:./db/database.db"
JWT_SECRET="ваш-очень-длинный-секретный-ключ-минимум-32-символа"
NODE_ENV="production"
EOF

# Создайте папку для БД
mkdir db
```

#### 6. Установите и соберите
```bash
bun install
bun run db:push
bun run build
```

#### 7. Используйте PM2 для автозапуска
```bash
# Установите PM2
bun add -g pm2

# Запустите приложение
pm2 start "bun run start" --name taskfocus

# Сохраните конфигурацию
pm2 save

# Настройте автозапуск
pm2 startup
```

#### 8. Настройте Nginx (опционально)
```bash
sudo apt install nginx
sudo nano /etc/nginx/sites-available/taskfocus
```

```nginx
server {
    listen 80;
    server_name your-domain.com;  # или IP адрес

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
# Активируйте сайт
sudo ln -s /etc/nginx/sites-available/taskfocus /etc/nginx/sites-enabled/

# Проверьте конфигурацию
sudo nginx -t

# Перезапустите Nginx
sudo systemctl restart nginx
```

#### 9. SSL сертификат (Let's Encrypt)
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

---

### Вариант 2: Windows Server (IIS)

#### 1. Установите Node.js
Скачайте с https://nodejs.org (версия LTS)

#### 2. Установите Bun
```powershell
powershell -c "irm bun.sh/install.ps1 | iex"
```

#### 3. Скопируйте файлы проекта
В папку, например `C:\inetpub\wwwroot\taskfocus`

#### 4. Создайте .env файл
```env
DATABASE_URL="file:./db/database.db"
JWT_SECRET="ваш-секретный-ключ-минимум-32-символа"
NODE_ENV="production"
```

#### 5. Установите зависимости и соберите
```powershell
cd C:\inetpub\wwwroot\taskfocus
bun install
bun run db:push
bun run build
```

#### 6. Установите PM2
```powershell
bun add -g pm2
pm2 start "bun run start" --name taskfocus
pm2-save
pm2-startup
```

#### 7. Настройте IIS как reverse proxy
- Установите URL Rewrite и Application Request Routing
- Настройте перенаправление на http://localhost:3000

---

### Вариант 3: Docker

#### 1. Создайте Dockerfile
```dockerfile
FROM oven/bun:1 AS base

WORKDIR /app

# Копируем файлы зависимостей
COPY package.json bun.lockb* ./
COPY prisma ./prisma/

# Устанавливаем зависимости
RUN bun install --frozen-lockfile

# Копируем исходники
COPY . .

# Генерируем Prisma клиент и собираем
RUN bun run db:generate
RUN bun run build

# Экспонируем порт
EXPOSE 3000

# Запускаем
CMD ["bun", "run", "start"]
```

#### 2. Создайте docker-compose.yml
```yaml
version: '3.8'

services:
  taskfocus:
    build: .
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=file:/app/db/database.db
      - JWT_SECRET=your-secret-key-change-this
      - NODE_ENV=production
    volumes:
      - taskfocus-db:/app/db
    restart: unless-stopped

volumes:
  taskfocus-db:
```

#### 3. Запустите
```bash
docker-compose up -d
```

---

## Продолжение разработки

### Рекомендуемые расширения VS Code

1. **ES7+ React/Redux/React-Native snippets**
2. **Tailwind CSS IntelliSense**
3. **TypeScript Importer**
4. **Prettier - Code formatter**
5. **ESLint**
6. **Prisma**

### Добавление новых фич

#### Новая страница
```bash
# Создайте папку и файл
src/app/new-page/page.tsx
```

#### Новый API endpoint
```bash
# Создайте route.ts
src/app/api/new-endpoint/route.ts
```

#### Новый компонент
```bash
# Создайте компонент
src/components/new-component.tsx
```

### Изменение базы данных

1. Отредактируйте `prisma/schema.prisma`
2. Примените изменения:
```bash
bun run db:push
```

### Использование PostgreSQL вместо SQLite

1. Измените `prisma/schema.prisma`:
```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

2. Измените `.env`:
```env
DATABASE_URL="postgresql://user:password@localhost:5432/taskfocus"
```

3. Примените миграцию:
```bash
bun run db:push
```

---

## Частые проблемы

### Ошибка "Module not found"
```bash
# Удалите node_modules и переустановите
rm -rf node_modules
bun install
```

### Ошибка базы данных
```bash
# Сбросьте базу данных
bun run db:reset
```

### Ошибка JWT
Убедитесь, что JWT_SECRET установлен в .env

---

## Контакты

При возникновении вопросов обращайтесь к документации:
- Next.js: https://nextjs.org/docs
- Prisma: https://www.prisma.io/docs
- Tailwind CSS: https://tailwindcss.com/docs
- shadcn/ui: https://ui.shadcn.com

---

**Удачи с дипломом! 🎓**
